
const config = {
    telegramAirdrop: "https://t.me/your_airdrop_channel",
    telegramCoupons: "https://t.me/your_coupons_channel",
    youtubeChannel: "https://youtube.com/your_channel",
    instagramProfile: "https://instagram.com/your_profile"
};

function initParticles() {
    const canvas = document.createElement('canvas');
    canvas.className = 'particles';
    document.getElementById('particles-js').appendChild(canvas);

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = [];
    for (let i = 0; i < 80; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            size: Math.random() * 4 + 1,
            speedX: Math.random() * 2 - 1,
            speedY: Math.random() * 2 - 1,
            color: `rgba(255, 255, 255, ${Math.random() * 0.5 + 0.1})`
        });
    }

    function animate() {
        ctx.fillStyle = 'rgba(15, 32, 39, 0.2)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        particles.forEach(p => {
            ctx.fillStyle = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();

            p.x += p.speedX;
            p.y += p.speedY;

            if (p.x < 0 || p.x > canvas.width) p.speedX *= -1;
            if (p.y < 0 || p.y > canvas.height) p.speedY *= -1;
        });

        requestAnimationFrame(animate);
    }

    animate();

    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

function initEventListeners() {
    document.getElementById('playBtn').addEventListener('click', () => {
        window.location.href = "game.html";
    });
    document.getElementById('airdropBtn').addEventListener('click', () => {
        window.open(config.telegramAirdrop, '_blank');
    });
    document.getElementById('couponsBtn').addEventListener('click', () => {
        window.open(config.telegramCoupons, '_blank');
    });
    document.getElementById('youtubeBtn').addEventListener('click', () => {
        window.open(config.youtubeChannel, '_blank');
    });
    document.getElementById('instagramBtn').addEventListener('click', () => {
        window.open(config.instagramProfile, '_blank');
    });
}

document.addEventListener('DOMContentLoaded', () => {
    initParticles();
    initEventListeners();
});
